﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ADONETDemos_ChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string OldPassword = Session["Sess_Password"].ToString();
        string EnteredPassword = TextBox1.Text;
        UserDetails x = new UserDetails();
        if(EnteredPassword.Equals(OldPassword))
        {
            x.Password = TextBox2.Text;
            x.UserName = Session["Sess_UserName"].ToString();
            int Counter = x.ChangePassword();
            if(Counter.Equals(1))
            {
                Session.Abandon();
                Response.Redirect("Login.aspx");
            }
            else
            {
                Label3.Text = "<h1>Your password couldnt be update...</h1>";
            }
        }
        else
        {
            Label3.Text = "<h1>Incorrect old Password! Try again..</h1>";
        }
    }
}