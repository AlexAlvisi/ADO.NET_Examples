﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ADONETDemos_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        UserDetails x = new UserDetails();
        x.UserName = TextBox1.Text;
        x.Password = TextBox2.Text;
        

        int Counter = x.CheckCredentials();

        if (Counter.Equals(1))
        {
            Session["Sess_Username"] = TextBox1.Text;
            Session["Sess_Password"] = TextBox2.Text;
            Response.Redirect("Home.aspx");
        }
        else
        {
            Label3.Text = "<h1>Invalid Credentials. Try again</h1>";
        }
        /*
        switch(Status)        
        {
            case 1:
                Session["Sess_UserName"] = TextBox1.Text;
                Session["Sess_Password"] = TextBox2.Text;
                Response.Redirect("Home.aspx");
                break;
            case -1:
                Label3.Text="<h1>No such user name does exist..</h1>";
                break;
            case -2:
                Label3.Text="<h1>you have unsubscribed in the past..So you cant login..</h1>";
                break;
            case -3:
                Label3.Text="<h1>Your account has been locked out due to too many failed attempts! Contact him..</h1>";
                break;
            case 0:
                int NOFA=Convert.ToInt32(dSet.Tables[0].Rows[0]["NOFA"].ToString());

                if (NOFA.Equals(5))
                {
                    Label3.Text = "<h1>You have exceeded maximum failed attempts and Your account has been locked out..</h1>";
                }
                else
                {
                    Label3.Text = "<h1>Wrong Password! You are left with " + (5 - NOFA) + " attempts..</h1>";
                }
                break;
        }
       */
    }
}