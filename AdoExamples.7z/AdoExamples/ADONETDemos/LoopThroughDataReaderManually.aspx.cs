﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class ADONETDemos_LoopThroughDataReaderManually : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            UserDetails x = new UserDetails();
            SqlDataReader sdr = x.GetListOfAllUsersUsingReader();
            ShowData(sdr);
        }
    }

    private void ShowData(SqlDataReader sdr)
    {
        bool blHasRows = true;

        while(blHasRows)
        {

            Response.Write("<table border=5 bgColor=aqua>");

            Response.Write("<tr>");

            for (int i = 0; i < sdr.FieldCount; i++)
            {
                Response.Write("<td>");
                Response.Write(sdr.GetName(i));
                Response.Write("</td>");
            }

            Response.Write("</tr>");


           

            while(sdr.Read())
            {
                Response.Write("<tr>");
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    Response.Write("<td>");
                    Response.Write(sdr.GetValue(i));
                    Response.Write("</td>");
                }

                Response.Write("</tr>");
            }
            
            Response.Write("</table>");

            blHasRows = sdr.NextResult();


        }
    }
}