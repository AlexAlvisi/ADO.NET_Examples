﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ADONETDemos_Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["Sess_UserName"] != null)
            {
                Label1.Text = "<h1>Welcome Back To " + Session["Sess_UserName"].ToString() + "</h1>";
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChangePassword.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        UserDetails x = new UserDetails();
        x.UserName = Session["Sess_UserName"].ToString();

        int Counter = x.Unsubscribe();

        if(Counter.Equals(1))
        {
            Session.Abandon();
            Response.Redirect("SignUp.aspx");
        }
        
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChangeProfile.aspx");
    }
}